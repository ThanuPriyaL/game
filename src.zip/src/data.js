import rose from './images/rose.jpg';
import lotus from './images/lotus.jpg';
import lily from './images/lily.jpg';
import marigold from './images/marigold.jpg';
import sunflower from './images/sunflower.jpg';
import tulip from './images/tulip.jpg';
import daisy from './images/daisy.jpg';
import lavender from './images/lavender.jpg';

const data = {
    productData:[
        {
            id:1,
            img:rose,
            title:'Rose-Flower',
            desc:'',
            price:46,
        },
        
        {
            id:2,
            img:lotus,
            title:'Lotus-Flower',
            desc:'',
            price:66,
        },
        {
            id:3,
            img:lily,
            title:'Lily-Flower',
            desc:'',
            price:66,
        },
        {
            id:4,
            img:marigold,
            title:'Marigold-Flower',
            desc:'',
            price:46,
        },
        
        {
            id:5,
            img:sunflower,
            title:'Sun-Flower',
            desc:'',
            price:66,
        },
        {
            id:6,
            img:tulip,
            title:'Tulip-Flower',
            desc:'',
            price:66,
        },
        {
            id:7,
            img:daisy,
            title:'Daisy-Flower',
            desc:'',
            price:46,
        },
        
        {
            id:8,
            img:lavender,
            title:'Lavender-Flower',
            desc:'',
            price:66,
        },
    ],
};
export default data;
