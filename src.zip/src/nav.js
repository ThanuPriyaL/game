import './nav.css';
import React from 'react';
function Nav(){
    return(
        <div>
        <div className='nav'>
        <nav>
          <a href='#'>Home</a>
          <a href='#'>About Us</a>
          <a href='#'>Galery</a>
          <a href='#'>Login</a>
          <a href='#'>Contact Us</a>
          <div className='animation start-home'></div>
        </nav>
        </div>
        </div>
    )
}
export default Nav;