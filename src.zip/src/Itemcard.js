import {useState,React}from 'react';
import { useCart} from "react-use-cart";
import './itemcard.css';
const Itemcard = (props) => {
  const [readMore,setReadMore]=useState(false);
         const { addItem } = useCart();
         const extraContent=<div>
         <p className="extra-content">
           Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui, consectetur neque ab 
           porro quasi culpa nulla rerum quis minus voluptatibus sed hic ad quo sint, libero 
           commodi officia aliquam! Maxime.
         </p>
     </div>
     const linkName=readMore?'Read less':'Read More '


    return(
        <div className="col-11 col-md-6 col-lg-3 mx-0 mb-4">
            <div class="card p-0 overflow-hidden h-100 shadow" alt="im">
  <img src={props.img} className="card-img-top img-fluid" alt={props.title}/>
  <div className="card-body text-center">
    <h5 className="card-title">{props.title}</h5>
    <h5 className="card-title">Rs.{props.price}</h5>
    <p className="card-text">{props.desc}</p>
    <button className="btn btn-success" 
    onClick={() =>addItem(props.item)}
    >Add to Cart</button><br></br><br></br>
    <button id="description" onClick={()=>{setReadMore(!readMore)}}> <h5>{linkName}</h5></button>
    {readMore && extraContent}
  </div>
</div>
            </div>
    );
};
 export default Itemcard;