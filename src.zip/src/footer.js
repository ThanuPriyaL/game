import './footer.css';
import React from 'react';
function Footer(){
    return(
        <div classname="container">
        <h4>Follow us</h4>
        {/* <box-icon type='logo' name='facebook-circle'></box-icon>|<box-icon name='instagram' type='logo' ></box-icon>|<box-icon name='youtube' type='logo' ></box-icon>|<box-icon type='logo' name='twitter'></box-icon>|<box-icon name='linkedin-square' type='logo' ></box-icon>  */}
        <div class="copyright">
          &copy; Copyright <strong>Flower-Store</strong>. All Rights Reserved
        </div>
      </div>
    )
}
export default Footer;