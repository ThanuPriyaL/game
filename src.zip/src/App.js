import React from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Home from "./Home";
import Cart from "./Cart";
import {CartProvider } from "react-use-cart"
import Nav from "./nav";
import Footer from "./footer";
function App() {
  return (
    <>
    <Nav></Nav>
    <CartProvider>
    <Home/>
    <Cart/>
    </CartProvider>
    <Footer></Footer>
    </>
    
  );
}

export default App;
