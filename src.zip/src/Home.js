import {React} from 'react';
import Itemcard from "./Itemcard";
import data from "./data";
const Home = () => {

    console.warn(data.productData)
 
    return(
        <>
            <section className="py-4 container">
                <div className="row justify-content-center">
                    {data.productData.map((items, index)=>{
                        return(
                            <Itemcard 
                            
                            img={items.img} 
                            title={items.title} 
                            desc={items.desc} 
                            price={items.price} 
                            item={items} 
                            key={index}
                            /> 
                        )

                    })}
                </div>
                
            </section>
        </>
    );
};
export default Home;