export class User
{
firstname:string='';
lastname: string='';
email:string='';
mobile:number=0;
pass: string='';
cpass: string='';
AccountType: string='';
}