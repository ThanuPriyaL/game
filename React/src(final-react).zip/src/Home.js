import React,{ useState }  from "react";
import Product from "../src/components/Product";
import data from "../src/data";
import './home.css'
import ear from './images/ear.jpg';
import pro from './images/pro.jpg';
import wa from './images/wa.jpg';
import watch from './images/watch.jpg';
import earp from './images/earp.jpg';
class Home extends React.Component{
    render(){
    const{products}=data;
    return(
        <div>
            <div> <h1 class="text-center mt-3">New Launchs</h1> 
            
            <section id="slider">
            <input type="radio" name="slider" id="s1"/>
            <input type="radio" name="slider" id="s2"/>
        <input type="radio" name="slider" id="s3" checked/>
    <input type="radio" name="slider" id="s4"/>
    <input type="radio" name="slider" id="s5"/>
    <label for="s1" id="slide1">
    <img src={wa} height="100%" width="100%"/>
    </label>
    <label for="s2" id="slide2">
    <img src={pro} height="100%" width="100%"/>
    </label>
    <label for="s3" id="slide3">
    <img src={ear} height="100%" width="100%"/>
    </label>
    <label for="s4" id="slide4">
    <img src={earp} height="100%" width="100%"/>
    </label>
    {/* <label for="s5" id="silde5">
    <img src={watch} height="100%" width="100%"/>
    </label> */}
    </section>
            </div>


             <div className="App">
             <h1 class="text-center mt-3">Products</h1> 
        <section class="container">
            <div class="row">
                {
                    products.map((item,index)=>{
                        return(
                            <Product 
                            img={item.image} 
                            name={item.name} 
                            desc={item.desc} 
                            price={item.price} 
                            item={item}
                            key={index} />
                        )
                    })
                }
                <br></br><br></br><br></br>
            </div>
        </section>
        </div>
        </div>
    );
}
}
export default Home;