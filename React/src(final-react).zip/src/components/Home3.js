import React,{ useState }  from "react";
import Product3 from "./Product3";
import data3 from "./../data3";
class Home3 extends React.Component{
    render(){
    const{products3}=data3;
    return(
        <div>
        <h1 class="text-center mt-3">View Products</h1>
        <section class="container">
            <div class="row">
                {
                    products3.map((item,index)=>{
                        return(
                            <Product3 
                            img={item.image} 
                            name={item.name} 
                            desc={item.desc} 
                            price={item.price} 
                            item={item}
                            key={index} />
                        )
                    })
                }
            </div>
        </section>
        </div>
    //     <main className="block col-2">
    //     <h2>Products</h2>
    //     <div className="row">
    //       {products.map((product) => (
    //         <Product key={product.id} product={product}></Product>
    //       ))}
    //     </div>
    //   </main>
    );
}
}
export default Home;