import React from 'react'

export default function Product3(props) {
    return (
        <div class="col-4">
        <div class="card">
        <img class="card-img-top img-fluid" src={props.img} alt="product"/>
        <div class="card-body text-center">
        <h5 class="card-title">{props.name}</h5>
        
        <p class="card-text">{props.desc}</p>
        <h4 class="card-title">{props.price} Rs</h4>
        </div>
        </div>
        </div>
        
    )
}
