import p11 from './images/p11.jpg';
import p12 from './images/p12.jpg';
import p13 from './images/p13.jpg';

const data1={
    products1:[
        {
        id:'1',
        name:'one-plus Phone',
        price:7500,
        desc:"The fresh spin on what you know best.The fresh spin on what you know best.The fresh spin on what you know best.",
        image:p11,
        },
        {
            id:'2',
            name:'Nike Dunk High Retro SE',
            price:10000,
            desc:"Go full throttle in the Nike Dunk Low High Retro.It brings motocross-inspired details like bold branding.",
            image:p12,
        },
        {
            id:'3',
            name:'Nike Air Zoom Tempo NEXT%',
            price:17000,
            desc:"While these speedsters could easily pass the test on race day, they double as your go-to shoe for your training routine.",
            image:p13,
        },        
    ]
}
export default data1;