import p1 from './images/p1.jpg';
import p2 from './images/p2.jpg';
import p3 from './images/p3.jpg';

const data={
    products:[
        {
        id:'1',
        name:'one-plus Phone',
        price:7500,
        desc:"The fresh spin on what you know best.The fresh spin on what you know best.",
        image:p1,
        },
        {
            id:'2',
            name:'Nike Dunk High Retro SE',
            price:10000,
            desc:"It brings motocross-inspired details like bold branding.",
            image:p2,
        },
        {
            id:'3',
            name:'Nike Air Zoom Tempo NEXT%',
            price:17000,
            desc:"While these speedsters could easily pass the test on race day.",
            image:p3,
        },        
    ]
}
export default data;