import p21 from './images/p21.jpg';
import p22 from './images/p22.jpg';
import p23 from './images/p23.jpg';

const data2={
    products2:[
        {
        id:'1',
        name:'one-plus Phone',
        price:7500,
        desc:"The fresh spin on what you know best.",
        image:p21,
        },
        {
            id:'2',
            name:'Nike Dunk High Retro SE',
            price:10000,
            desc:"Go full throttle in the Nike Dunk Low High Retro.It brings motocross-inspired details like bold branding.",
            image:p22,
        },
        {
            id:'3',
            name:'Nike Air Zoom Tempo NEXT%',
            price:17000,
            desc:"While these speedsters could easily pass the test on race day, they double as your go-to shoe for your training routine.",
            image:p23,
        },        
    ]
}
export default data2;