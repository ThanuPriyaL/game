import p31 from './images/p31.jpg';
import p32 from './images/p32.jpg';
import p33 from './images/p33.jpg';

const data3={
    products3:[
        {
        id:'1',
        name:'one-plus Phone',
        price:7500,
        desc:"The fresh spin on what you know best.",
        image:p31,
        },
        {
            id:'2',
            name:'Nike Dunk High Retro SE',
            price:10000,
            desc:"Go full throttle in the Nike Dunk Low High Retro.It brings motocross-inspired details like bold branding.",
            image:p32,
        },
        {
            id:'3',
            name:'Nike Air Zoom Tempo NEXT%',
            price:17000,
            desc:"While these speedsters could easily pass the test on race day, they double as your go-to shoe for your training routine.",
            image:p33,
        },        
    ]
}
export default data3;