import React,{ useState }  from "react";
import Product2 from "./Product2";
import data2 from "./../data2";
class Home2 extends React.Component{
    render(){
    const{products2}=data2;
    return(
        <div>
        <h1 class="text-center mt-3">View Products</h1>
        <section class="container">
            <div class="row">
                {
                    products2.map((item,index)=>{
                        return(
                            <Product2 
                            img={item.image} 
                            name={item.name} 
                            desc={item.desc} 
                            price={item.price} 
                            item={item}
                            key={index} />
                        )
                    })
                }
            </div>
        </section>
        </div>
    //     <main className="block col-2">
    //     <h2>Products</h2>
    //     <div className="row">
    //       {products.map((product) => (
    //         <Product key={product.id} product={product}></Product>
    //       ))}
    //     </div>
    //   </main>
    );
}
}
export default Home2;