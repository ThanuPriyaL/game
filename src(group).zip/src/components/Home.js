import React,{ useState }  from "react";
import Product from "./Product";
import data from "./../data";
class Home extends React.Component{
    render(){
    const{products}=data;
    return(
        <div>
        <h1 class="text-center mt-3">Products</h1>
        <section class="container">
            <div class="row">
                {
                    products.map((item,index)=>{
                        return(
                            <Product 
                            img={item.image} 
                            name={item.name} 
                            desc={item.desc} 
                            price={item.price} 
                            item={item}
                            key={index} />
                        )
                    })
                }
            </div>
        </section>
        </div>
    );
}
}
export default Home;