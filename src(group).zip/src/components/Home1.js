import React,{ useState }  from "react";
import Product1 from "./Product1";
import data1 from "./../data1";
class Home1 extends React.Component{
    render(){
    const{products1}=data1;
    return(
        <div>
        <h1 class="text-center mt-3">View Products</h1>
        <section class="container">
            <div class="row">
                {
                    products1.map((item1,index1)=>{
                        return(
                            <Product1
                            img={item1.image} 
                            name={item1.name} 
                            desc={item1.desc} 
                            price={item1.price} 
                            item={item1}
                            key={index1} />
                        )
                    })
                }
            </div>
        </section>
        </div>
    );
}
}
export default Home1;